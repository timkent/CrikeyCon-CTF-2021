#!/usr/bin/env python3

from datetime import datetime
from pathlib import Path
from random import Random

flag = input().encode()

r = Random(str(datetime.now()))

rb = r.randbytes(32)
ct = bytes([a ^ b for a, b in zip(rb, flag)])

Path('ct.bin').write_bytes(ct)
